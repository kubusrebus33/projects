using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; 
using System;

namespace mainSceneManager{
    public class sceneManager : MonoBehaviour
    {
        public static int gameLevel { get; set; }

        public static void changeToGameScene(int mode){
            if(mode == 0){
                Physics2D.gravity = new Vector2(0, -0.81F);
                Debug.Log("LEVEL EASY");
                MoveObject.lifetime = 8F;
            }
            else if(mode == 1){
                Physics2D.gravity = new Vector2(0, -2.81F);
                Debug.Log("LEVEL NORMAL");
                MoveObject.lifetime = 5F;
            } 
            else if(mode == 2){
                Physics2D.gravity = new Vector2(0, -4.81F);
                Debug.Log("LEVEL HARD");
                MoveObject.lifetime = 4F;
            }
            else if(mode == 3){
                Physics2D.gravity = new Vector2(0, -0.81F);
                Debug.Log("LEVEL INFINITY");
                MoveObject.lifetime = 8F;
            }
            SceneManager.LoadScene("gameScene");  
        }

        public void changeToMenuScene(){
            objectSpawner.sprites.Clear();
            SceneManager.LoadScene("mainScene");  
        }
        
        public void chooseLevel(int chosenLevel){
            gameLevel = chosenLevel;
        }

        public void doExitGame() {
            Application.Quit();
            Debug.Log("Game is exiting");
        }  
    }
}