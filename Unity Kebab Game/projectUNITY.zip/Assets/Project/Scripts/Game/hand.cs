using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hand : MonoBehaviour
{

    // Update is called once per frame
    void Update(){
        if(Camera.main.ScreenToWorldPoint(Input.mousePosition).x > 2.3f){
            gameObject.transform.position = new Vector2(2.3f, -4);
        }
        else if(Camera.main.ScreenToWorldPoint(Input.mousePosition).x < -2.3f){
            gameObject.transform.position = new Vector2(-2.3f, -4);
        }
        else{
            gameObject.transform.position = new Vector2(Camera.main.ScreenToWorldPoint(Input.mousePosition).x, -4);
        }
    }
}
