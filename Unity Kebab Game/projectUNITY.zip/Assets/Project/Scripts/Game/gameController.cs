using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; 
using System;
using System.Threading;
using UnityEngine.UI;

namespace mainSceneManager{
    public class gameController : MonoBehaviour
    {
        private float i = 0;
        // Start is called before the first frame update
        public static void startAgain()
        {
            // GameObject.Find("heart3").SetActive(true);
            SceneManager.LoadScene("mainScene");  
            SceneManager.LoadScene("gameScene");  
            buttonHandler.startGame();
            heartController.lifes = 3;
        }
        void updateGame(){
            if(sceneManager.gameLevel ==  6){
                Debug.Log(i);
                i -= 0.1F;
                Physics2D.gravity = new Vector2(0, -0.81F+i);
            }
        }
        void Start(){
            InvokeRepeating("updateGame", 0.0f, 1.0f);
        }
    }   
}