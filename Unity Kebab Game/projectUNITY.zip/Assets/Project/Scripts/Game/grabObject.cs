using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace mainSceneManager{
    public class grabObject : MonoBehaviour{

        public bool contraband;
        public static List<string> currentIngredientsList;
        public static List<int> currentQuantityList;

        public static void setIngredients(){
            currentIngredientsList = allScenarios.currentIngredients.ToList();
            currentQuantityList = allScenarios.currentQuantity.ToList();
        }

        void OnCollisionEnter2D (Collision2D collision){
            if (collision.gameObject.tag == "Cut"){

                //Dissapearing gameobject
                Destroy(gameObject);

                //Adding or substracting score points
                if (contraband){
                    GameObject.Find("scoreText").transform.GetComponent<scoreText>().Score -= 2;
                }
                else{
                    GameObject.Find("scoreText").transform.GetComponent<scoreText>().Score += 10;
                }

                if (contraband && sceneManager.gameLevel == 6){
                    switch (heartController.lifes){
                        case 3:
                            //heart dissapear
                            GameObject.Find("heart3").SetActive(false);
                            heartController.lifes--;
                            break;
                        case 2:
                            //heart dissapear
                            GameObject.Find("heart2").SetActive(false);
                            heartController.lifes--;
                            break;
                        case 1:
                            //heart dissapear
                            GameObject.Find("heart1").SetActive(false);
                            heartController.lifes--;
                            
                            //stop game
                            buttonHandler.pauseGame();

                            //show end panel screen
                            GameObject.Find("switchEndPanel").GetComponent<Button>().onClick.Invoke();

                            //show score
                            GameObject.Find("endScore").GetComponent<Text>().text = GameObject.Find("scoreText").GetComponent<Text>().text;

                            //hide hand cursor
                            GameObject.Find("hand").SetActive(false);
                            break;
                    }
                }else if (contraband == false && sceneManager.gameLevel != 6){
                    string tempIngredients = "";
                    string tempQuantity = "";
                    string tempX = "";

                        for(int i = 0; i < currentIngredientsList.Count; i++){
                            if (gameObject.GetComponent<Image>().sprite.name == currentIngredientsList[i] && currentQuantityList[i] > 1){
                                currentQuantityList[i] -= 1;
                                tempIngredients += currentIngredientsList[i] + "\n";
                                tempQuantity += currentQuantityList[i] + "\n";
                                tempX += "x\n";
                            }else if (gameObject.GetComponent<Image>().sprite.name == currentIngredientsList[i] && currentQuantityList[i] == 1){
                                
                                currentIngredientsList.RemoveAt(i);    
                                currentQuantityList.RemoveAt(i); 

                                    for(int j = 0; j < objectSpawner.sprites.Count; j++){
                                        if(gameObject.GetComponent<Image>().sprite.name == objectSpawner.sprites[j].name){
                                            objectSpawner.sprites.RemoveAt(j);
                                        }
                                    }
                                i--;
                            }else {
                                tempIngredients += currentIngredientsList[i] + "\n";
                                tempQuantity += currentQuantityList[i] + "\n";
                                tempX += "x\n";
                            }
                        }
                    GameObject.Find("amount").GetComponent<Text>().text = tempQuantity;
                    GameObject.Find("ingredients").GetComponent<Text>().text = tempIngredients;
                    GameObject.Find("x").GetComponent<Text>().text = tempX;
                }
                if(currentIngredientsList.Count == 0){
                    buttonHandler.pauseGame();
                    GameObject.Find("switchFinishPanel").GetComponent<Button>().onClick.Invoke();
                    GameObject.Find("hand").SetActive(false);
                    GameObject.Find("finishScore").GetComponent<Text>().text = GameObject.Find("scoreText").GetComponent<Text>().text;
                } 
		          
            }
        }
    }
}
