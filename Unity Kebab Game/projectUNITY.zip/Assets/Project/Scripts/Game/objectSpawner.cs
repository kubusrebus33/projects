using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace mainSceneManager{

    public class objectSpawner : MonoBehaviour{

        [Header("Target")]
        public GameObject prefab;

        [Header("Gameplay")]
        public float interval;
        public float minimumX;
        public float maximumX;
        public float y;
        public int chosenGameLevel;

        public static List<Sprite> sprites = new List<Sprite>();

        // Start is called before the first frame update
        void Start(){
            InvokeRepeating("Spawn", interval, interval);
        }

        private void Spawn(){
            //instantiate and position the object
            GameObject instance = Instantiate(prefab);
            instance.transform.position = new Vector2(
                Random.Range(minimumX, maximumX),
                y
            );
            
            //spawning clones inside parents 
            instance.transform.SetParent(transform);

            //select a randomsprite
            Sprite randomSprite = sprites[Random.Range(0, sprites.Count)];
            instance.GetComponent<Image>().sprite = randomSprite;
        }
    }
}