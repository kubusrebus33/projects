using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System;

namespace mainSceneManager{
    public class allScenarios : MonoBehaviour{
                                                //  0          1             2                3              4             5       6        7           8          9        10          11
        public static string[] allIngredients = {"Bułka", "Tortilla", "Sos mieszany", "Sos czosnkowy", "Sos ostry", "Pomidor", "Ogórek", "Sałata", "Cebula", "Frytki", "Wołowina", "Falafel"};   

        public static string[] firstScenarioIngredients = {allIngredients[0], allIngredients[2], allIngredients[5], allIngredients[8], allIngredients[10]};
        public static int[] firstScenarioQuantity = {1, 2, 5, 2, 3};

        public static string[] secondScenarioIngredients = {allIngredients[1], allIngredients[3], allIngredients[6], allIngredients[7], allIngredients[9], allIngredients[11]};
        public static int[] secondScenarioQuantity = {1, 1, 4, 3, 1, 2};

        public static string[] thirdScenarioIngredients = {allIngredients[0], allIngredients[2], allIngredients[5], allIngredients[7], allIngredients[8], allIngredients[9], allIngredients[10]};
        public static int[] thirdScenarioQuantity = {1, 2, 5, 2, 3, 4, 2};

        public static string[] fourthScenarioIngredients = {allIngredients[1], allIngredients[4], allIngredients[5], allIngredients[6], allIngredients[7], allIngredients[8], allIngredients[9], allIngredients[10]};
        public static int[] fourthScenarioQuantity = {1, 1, 2, 5, 3, 1, 3, 4};

        public static string[] fifthScenarioIngredients = {allIngredients[0], allIngredients[3], allIngredients[5], allIngredients[6], allIngredients[7], allIngredients[8], allIngredients[9], allIngredients[10], allIngredients[11]};
        public static int[] fifthScenarioQuantity = {1, 1, 2, 5, 3, 1, 3, 4, 5};

        public static string[] currentIngredients;
        public static int[] currentQuantity;
        
        
        // Start is called before the first frame update
        void Start(){
            switch(sceneManager.gameLevel){
                case 1:
                    currentIngredients = new string[] {allIngredients[0], allIngredients[2], allIngredients[5], allIngredients[8], allIngredients[10]};
                    currentQuantity = new int[] {1, 2, 5, 2, 3};
                    break;
                case 2:
                    currentIngredients = new string[] {allIngredients[1], allIngredients[3], allIngredients[6], allIngredients[7], allIngredients[9], allIngredients[11]};
                    currentQuantity = new int[] {1, 1, 4, 3, 1, 2};
                    break;
                case 3:
                    currentIngredients = new string[] {allIngredients[0], allIngredients[2], allIngredients[5], allIngredients[7], allIngredients[8], allIngredients[9], allIngredients[10]};
                    currentQuantity = new int[] {1, 2, 5, 2, 3, 4, 2};
                    break;
                case 4:
                    currentIngredients = new string[] {allIngredients[1], allIngredients[4], allIngredients[5], allIngredients[6], allIngredients[7], allIngredients[8], allIngredients[9], allIngredients[10]};
                    currentQuantity = new int[] {1, 1, 2, 5, 3, 1, 3, 4};
                    break;
                case 5:
                    currentIngredients = new string[] {allIngredients[0], allIngredients[3], allIngredients[5], allIngredients[6], allIngredients[7], allIngredients[8], allIngredients[9], allIngredients[10], allIngredients[11]};
                    currentQuantity = new int[] {1, 1, 2, 5, 3, 1, 3, 4, 5};
                    break;
                case 6:
                    currentIngredients = allIngredients;
                    currentQuantity = new int[] {};
                    GameObject.Find("list").SetActive(false);
                    break;
            }
                for(int i = 0; i < currentIngredients.Length; i++){
                    objectSpawner.sprites.Add(Resources.Load<Sprite>(currentIngredients[i]));
                }

                conSpawner.sprites.Add(Resources.Load<Sprite>("con1"));
                conSpawner.sprites.Add(Resources.Load<Sprite>("con2"));
                grabObject.setIngredients();
        }
    }
}
