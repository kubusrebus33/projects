using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class scoreText : MonoBehaviour{
    private int score = 0;

    public int Score{
        get {
            return score;
        }
        set {
            score = value;
            GetComponent<Text> ().text = "Wynik: " + score;
        }
    }

    void Start(){
        Score = 0;
    }

}
