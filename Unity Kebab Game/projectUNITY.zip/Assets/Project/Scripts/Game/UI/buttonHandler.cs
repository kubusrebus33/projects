using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement; 

namespace mainSceneManager{
    public class buttonHandler : MonoBehaviour{

        public static void pauseGame(){
            Time.timeScale = 0;
        }

        public static void startGame(){
            Time.timeScale = 1;
        }
        public static void switchToNextLevel(){
            sceneManager.gameLevel += 1;

            // Wyczyszczenie tablicy sprite'ów
            objectSpawner.sprites.Clear();

            SceneManager.LoadScene("mainScene");

            if(sceneManager.gameLevel == 6){
                sceneManager.changeToGameScene(3);
            }
            else{
                sceneManager.changeToGameScene(sceneManager.gameLevel);
            }
            startGame();
        }
        public void setActiveList(){
            if(sceneManager.gameLevel != 6 && sceneManager.gameLevel != 0){
                GameObject.Find("amount-p").GetComponent<Text>().text = GameObject.Find("amount").GetComponent<Text>().text;
                GameObject.Find("ingredients-p").GetComponent<Text>().text = GameObject.Find("ingredients").GetComponent<Text>().text;
                GameObject.Find("x-p").GetComponent<Text>().text = GameObject.Find("x").GetComponent<Text>().text;
            }
            else{
                if(GameObject.Find("Panel-p") != null){
                    GameObject.Find("Panel-p").SetActive(false);
                }
            }
        }
    }
}