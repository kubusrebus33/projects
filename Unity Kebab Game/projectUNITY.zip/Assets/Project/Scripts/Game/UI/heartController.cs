using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace mainSceneManager{
    public class heartController : MonoBehaviour
    {
        public static int lifes = 3;
        // Start is called before the first frame update
        void Start()
        {
            if(sceneManager.gameLevel == 6)  {
                GameObject.Find("hearts").SetActive(true);
            }
            else{
                GameObject.Find("hearts").SetActive(false);
            }
        }

    }
}