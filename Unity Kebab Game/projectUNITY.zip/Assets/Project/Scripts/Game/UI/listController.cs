using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

namespace mainSceneManager{
    public class listController : MonoBehaviour
    {
        GameObject ingredients;

        // Start is called before the first frame update
        void Start(){
            //przypisanie elementów kebaba do listy
            
            // Debug.Log("currentIngredients Length: " + allScenarios.currentIngredients.Length);
            GameObject.Find("ingredients").GetComponent<Text>().text = "";

            string tempIngredients = "";
            string tempQuantity = "";
            string tempX = "";
                for(int i = 0; i < allScenarios.currentIngredients.Length; i++){
                    // Debug.Log("currentIngredients Length: " + allScenarios.currentIngredients[i]);
                    tempIngredients += allScenarios.currentIngredients[i] + "\n";
                    tempQuantity += allScenarios.currentQuantity[i] + "\n";
                    tempX += "x\n";
                }
            GameObject.Find("amount").GetComponent<Text>().text = tempQuantity;
            GameObject.Find("ingredients").GetComponent<Text>().text = tempIngredients;
            GameObject.Find("x").GetComponent<Text>().text = tempX;
        }

        // Update is called once per frame
        void Update(){
            
        }
    }
}
