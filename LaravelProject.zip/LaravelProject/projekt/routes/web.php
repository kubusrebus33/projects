<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Controllers;
//use App\Http\Controllers\UsersController;
use App\Http\Controllers\FieldOfStudyController;    

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::middleware('auth')->group(function(){
    Route::get('/formularz1', [App\Http\Controllers\FormController::class, 'form1']);
    Route::get('/formularz2', [App\Http\Controllers\FormController::class, 'form2']);

    Route::post('/formularz2', [App\Http\Controllers\FormController::class, 'createResult']);
    Route::post('/formularz1', [App\Http\Controllers\FormController::class, 'createApplication']);

    Route::get('/profile', [App\Http\Controllers\UsersController::class, 'profile']);
});
Route::middleware('can:isAdmin')->group(function(){
    
    Route::get('/kierunki', [App\Http\Controllers\FieldOfStudyController::class, 'index2']);
    Route::get('/kierunki/create', [App\Http\Controllers\FieldOfStudyController::class, 'create']);
    Route::post('/kierunki/create', [App\Http\Controllers\FieldOfStudyController::class, 'store']);
    Route::get('/kierunki/{fieldofstudy}', [App\Http\Controllers\FieldOfStudyController::class, 'show']);
    Route::get('/kierunki/edit/{fieldofstudy}', [App\Http\Controllers\FieldOfStudyController::class, 'edit']);
    Route::post('/kierunki/{fieldofstudy}', [App\Http\Controllers\FieldOfStudyController::class, 'update']);
    Route::get('/delete/{fieldofstudy}', [App\Http\Controllers\FieldOfStudyController::class, 'delete']);
    
    });

Route::get('/student', [App\Http\Controllers\PagesController::class, 'student']);
Route::get('/', [App\Http\Controllers\PagesController::class, 'index']);
Route::get('/home', [App\Http\Controllers\PagesController::class, 'index']);
Route::get('/kandydat', [App\Http\Controllers\PagesController::class, 'kandydat']);
Route::get('/kontakt', [App\Http\Controllers\PagesController::class, 'kontakt']);
Route::get('/info1', [App\Http\Controllers\PagesController::class, 'info1']);
Route::get('/sukces', [App\Http\Controllers\PagesController::class, 'sukces']);

Route::get('/zapiszsie1', [App\Http\Controllers\FieldOfStudyController::class, 'index']);

Auth::routes(); 

Route::resource('users', UsersController::class);


