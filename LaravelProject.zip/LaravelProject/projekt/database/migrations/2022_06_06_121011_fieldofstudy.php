<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fieldofstudy', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->string('level')->nullable();
            $table->string('length')->nullable();
            $table->string('recruitment_fee')->nullable();
            $table->timestamps();
        });
        DB::table('fieldofstudy')->insert(
            array(
                'name' => 'informatyka',
                'level' => 'I stopień',
                'length' => 7,
                'recruitment_fee' => 100,
            )
        );
        DB::table('fieldofstudy')->insert(
            array(
                'name' => 'matematyka',
                'level' => 'I stopień',
                'length' => 6,
                'recruitment_fee' => 90,
            )
        );
        DB::table('fieldofstudy')->insert(
            array(
                'name' => 'fizyka',
                'level' => 'I stopień',
                'length' => 7,
                'recruitment_fee' => 150,
            )
        );
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fieldofstudy');
    }
};
