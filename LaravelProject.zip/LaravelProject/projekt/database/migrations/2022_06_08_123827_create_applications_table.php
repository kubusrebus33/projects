<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('applications', function (Blueprint $table) {
            $table->id();
            $table->string("pesel")->nullable();  
            $table->date("data_urodzenia")->nullable();  
            $table->string("imię_matki")->nullable();  
            $table->string("imię_ojca")->nullable();      
            $table->string("numer_telefonu")->nullable();           
            $table->string("kod_pocztowy")->nullable();   
            $table->string("ulica")->nullable(); 
            $table->integer("numer_domu")->nullable(); 
            $table->string("województwo")->nullable(); 
            $table->string("miejscowość")->nullable();  
            $table->string("nazwa_szkoły")->nullable();  
            $table->string("obywatelstwo")->nullable(); 
            $table->string("kierunek"); 
            $table->timestamps();
    
            $table->foreignId('user_id')->nullable()->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('applications');
    }
};
