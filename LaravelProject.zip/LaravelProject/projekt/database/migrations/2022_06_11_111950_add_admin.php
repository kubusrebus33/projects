<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\User;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */

    public function up()
    {
        $user = User::create([
            'name' => 'admin3',
            'surname' => 'admin3',
            'email' => 'admin3@o2.pl',
            'password' => Hash::make('123123123'),
            'role'=> 'admin'
    ]);
        Auth::login($user);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        
    }
};
