

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row"> 
        <div class="col-4">
            <h1><b>Aktualności</b></h1><hr>
            <br>
            <div>
                <h3>START REKRUTACJI na studia I stopnia i jednolite magisterskie oraz na studia II stopnia </h3>
            </div>
            <br><br>
            <div>
                <h5>W środę, 1 czerwca 2022 roku o godzinie 12:00, rozpoczęła się rejestracja na wszystkie studia pierwszego stopnia oraz na studia drugiego stopnia prowadzone w języku polskim w roku akademickim 2022/2023 na Uniwersytecie Rzeszowskim.  </h5>
            </div>
        </div> 
        <div class="col-8">
            <div>
                <h1><b><?php echo e($title); ?></b></h1><hr>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekt\resources\views/pages/info2.blade.php ENDPATH**/ ?>