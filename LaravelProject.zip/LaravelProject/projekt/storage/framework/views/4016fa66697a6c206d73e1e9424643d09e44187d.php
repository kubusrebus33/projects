

<?php $__env->startSection('content'); ?>
            <div>
                <h1><b><?php echo e($title); ?></b></h1><hr>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekt\resources\views/pages/student.blade.php ENDPATH**/ ?>