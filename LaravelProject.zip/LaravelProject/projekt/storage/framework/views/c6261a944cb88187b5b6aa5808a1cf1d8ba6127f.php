<?php $__env->startSection('content'); ?>
            
                <h1><b>Studia I stopnia</b></h1><hr>
                <?php if($message = Session::get('status')): ?>
                  <div class="alert alert-success alert-block text-green-600">
                        <strong><?php echo e($message); ?></strong> 
                  </div>          
                <?php endif; ?>
            <div>
                <form action="<?php echo e(url('/zapiszsie1')); ?>">
                    <input type="submit" style="height:60px; background-color:rgb(126, 180, 235); color:Black; width:200px; font-size:27px;" value="Zapisz się!" />
                </form>
                <br>
                <form action="<?php echo e(url('/info1')); ?>">
                    <input type="submit" style="height:60px; background-color:rgb(126, 180, 235); color:Black; width:200px; font-size:27px;" value="Informacje" />
                </form>
                <br>

            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekt\resources\views/home.blade.php ENDPATH**/ ?>