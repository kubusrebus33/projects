

<?php $__env->startSection('content'); ?>
            <h1> Moje dane </h1><hr><br>
                    
                    <table class="table table-hover">
                        <thead>
                            <h5>Dane użytkownika:</h5>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">imię</th>
                            <th scope="col">nazwisko</th>
                            <th scope="col">email</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>    
                        <th scope="row"><?php echo e($data->id); ?></th>
                        <td><?php echo e($data->name); ?></td>
                        <td><?php echo e($data->surname); ?></td>
                        <td><?php echo e($data->email); ?></td>
                    </tbody>
                    </table><br>
                    <hr>
                    <table class="table table-hover">
                        <thead>
                            <h5>Moje wyniki z matur:</h5>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">matematyka</th>
                            <th scope="col">matematykar</th>
                            <th scope="col">jpolski</th>
                            <th scope="col">jangielski</th>
                            <th scope="col">jangielskir</th>
                            <th scope="col">informatyka</th>
                            <th scope="col">fizyka</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>   
                        <th scope="row"><?php echo e($data->id); ?></th>
                        <td><?php echo e($data->matematyka); ?></td>
                        <td><?php echo e($data->matematykar); ?></td>
                        <td><?php echo e($data->jpolski); ?></td>
                        <td><?php echo e($data->jangielski); ?></td>
                        <td><?php echo e($data->jangielskir); ?></td>
                        <td><?php echo e($data->informatyka); ?></td>
                        <td><?php echo e($data->fizyka); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                    </tbody>
                    </table>
                    <br>
                    <hr>
                </div>
                
                    <table class="table table-hover">
                        <thead>
                            <h5>Moje dane osobowe</h5>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">pesel</th>
                            <th scope="col">data urodzenia</th>
                            <th scope="col">imię matki</th>
                            <th scope="col">imię ojca</th>
                            <th scope="col">numer telefonu</th>
                            <th scope="col">kod pocztowy</th>
                            <th scope="col">ulica</th>
                            <th scope="col">numer domu</th>
                            <th scope="col">województwo</th>
                            <th scope="col">miejscowość</th>
                            <th scope="col">nazwa szkoły</th>
                            <th scope="col">obywatelstwo</th>
                            <th scope="col">kierunek</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <tr>   
                        <th scope="row"><?php echo e($data->id); ?></th>
                        <td><?php echo e($data->pesel); ?></td>
                        <td><?php echo e($data->data_urodzenia); ?></td>
                        <td><?php echo e($data->imię_matki); ?></td>
                        <td><?php echo e($data->imię_ojca); ?></td>
                        <td><?php echo e($data->numer_telefonu); ?></td>
                        <td><?php echo e($data->kod_pocztowy); ?></td>
                        <td><?php echo e($data->ulica); ?></td>
                        <td><?php echo e($data->numer_domu); ?></td>
                        <td><?php echo e($data->województwo); ?></td>
                        <td><?php echo e($data->miejscowość); ?></td>
                        <td><?php echo e($data->nazwa_szkoły); ?></td>
                        <td><?php echo e($data->obywatelstwo); ?></td>
                        <td><?php echo e($data->kierunek); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                    </tbody>
                    </table>
                
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekt\resources\views/pages/profile.blade.php ENDPATH**/ ?>