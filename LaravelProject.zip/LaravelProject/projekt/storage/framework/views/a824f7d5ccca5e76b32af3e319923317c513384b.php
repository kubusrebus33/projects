

<?php $__env->startSection('content'); ?>
            <div>
                <h1><b>Zapisz się na studia I stopnia</b></h1><hr>

                <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class="well">
                        <a href="/formularz1"><h1><?php echo e($field->name); ?></a></h1>
                            <h5>---Poziom: <?php echo e($field->level); ?></h5>
                            <h5>---Ilość semestrów: <?php echo e($field->length); ?></h5>
                            <h5>---Opłata rekrutacyjna: <?php echo e($field->recruitment_fee); ?></h5>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>   
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekt\resources\views/pages/zapiszsie1.blade.php ENDPATH**/ ?>