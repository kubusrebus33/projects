

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-6"> 
        <h1><b>Kierunki</b></h1>
        </div>
        <div class="col-6"> 
        <a href="/kierunki/create">
            <button type="button" style="float:right;" class="btn btn-success"> Dodaj </button>
        </a>
    </div>
    <hr>
    </div>  
            <div class="row">
                
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">nazwa</th>
                        <th scope="col">poziom</th>
                        <th scope="col">dlugosc trwania</th>
                        <th scope="col">oplata</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>   
                        <th scope="row"><?php echo e($field->id); ?></th>
                        <td><?php echo e($field->name); ?></td>
                        <td><?php echo e($field->level); ?></td>
                        <td><?php echo e($field->length); ?></td>
                        <td><?php echo e($field->recruitment_fee); ?></td>
                        
                        <td>  
                            <a href="/kierunki/<?php echo e($field->id); ?>">
                                <button class="btn btn-primary btn-sm" data-id="<?php echo e($field -> id); ?>">
                                    Show
                                </button>   
                                 </a>  
                            <a href="/kierunki/edit/<?php echo e($field->id); ?>">
                                <button class="btn btn-warning btn-sm" data-id="<?php echo e($field -> id); ?>">
                                    Edit
                                </button>
                            </a>
                            <a href="/delete/<?php echo e($field->id); ?>">
                            <button class="btn btn-danger btn-sm" data-id="<?php echo e($field -> id); ?>">
                                Del
                            </button>   
                             </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
        </div>
        </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekt\resources\views/pages/kierunki.blade.php ENDPATH**/ ?>