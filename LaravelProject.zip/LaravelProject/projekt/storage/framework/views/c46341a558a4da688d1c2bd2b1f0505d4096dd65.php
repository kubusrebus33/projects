

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Podgląd kierunku</div>

                <div class="card-body">

                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">Nazwa</label>

                            <div class="col-md-6">
                                <input name="name" type="text" value="<?php echo e($fields ->name); ?>" disabled>

                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="level" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Poziom')); ?></label>

                            <div class="col-md-6">
                                <input name="level" type="text" name="level" value="<?php echo e($fields ->level); ?>" disabled>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="length" class="col-md-4 col-form-label text-md-end"><?php echo e(__('długość')); ?></label>

                            <div class="col-md-6">
                                <input name="length" type="text" value="<?php echo e($fields ->length); ?>" disabled>
                                
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="recruitment_fee" class="col-md-4 col-form-label text-md-end"><?php echo e(__('opłata')); ?></label>

                            <div class="col-md-6">
                                <input name="recruitment_fee" type="text" value="<?php echo e($fields ->recruitment_fee); ?>" disabled>

                            </div>
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekt\resources\views/pages/show.blade.php ENDPATH**/ ?>