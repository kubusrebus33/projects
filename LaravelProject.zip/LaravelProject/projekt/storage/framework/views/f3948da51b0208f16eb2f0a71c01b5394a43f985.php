

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row"> 
        <div class="col-4">
            <h1><b>Aktualności</b></h1><hr>
            <br>
            <div>
                <h3>START REKRUTACJI na studia I stopnia i jednolite magisterskie oraz na studia II stopnia </h3>
            </div>
            <br><br>
            <div>
                <h5>W środę, 1 czerwca 2022 roku o godzinie 12:00, rozpoczęła się rejestracja na wszystkie studia pierwszego stopnia oraz na studia drugiego stopnia prowadzone w języku polskim w roku akademickim 2022/2023 na Uniwersytecie Rzeszowskim.  </h5>
            </div>
        </div> 
        <div class="col-8">
            <form>        
                <div class="mb-3">
                    <label for="pesel" class="form-label">PESEL</label>
                    <label for="dataurodzenia" class="form-label" style="margin-left:305px;">Data urodzenia</label>

                    <input type="tel" style ="width:250px;float:left;margin-right:100px;" class="form-control" id="pesel">
                    <input type="date" style ="width:250px;" class="form-control" id="dataurodzenia">
                  </div>
                  <div class="mb-3">
                    <label for="imiematki" class="form-label">Imię matki</label>
                    <label for="imieojca" class="form-label" style="margin-left:285px;">Imię ojca</label><br>
                    <input type="text" style ="width:250px;float:left;margin-right:100px;" class="form-control" id="imiematki">
                    <input type="text" style ="width:250px;" class="form-control" id="imieojca">
                  </div>
                  <div class="mb-3">
                    <label for="nrtel" class="form-label">Numer telefonu</label>
                    <label for="kodpocztowy" class="form-label" style="margin-left:250px;">Kod pocztowy</label><br>

                    <input type="tel" style ="width:250px;float:left;margin-right:100px;" class="form-control" id="nrtel">
                    <input type="text" pattern="^\d{2}-\d{3}$" style ="width:250px;" class="form-control" id="kodpocztowy">
                  </div>
                  <div class="mb-3">
                    <label for="ulica" class="form-label">Ulica</label>
                    <label for="nrdomu" class="form-label" style="margin-left:318px;">Numer domu</label><br>

                    <input type="text" style ="width:250px;float:left;margin-right:100px;" class="form-control" id="ulica">
                    <input type="tel" style ="width:250px;" class="form-control" id="nrdomu">
                  </div>
                  <div class="mb-3">
                    <label for="wojewodztwo" class="form-label">Województwo</label>
                    <label for="miejscowosc" class="form-label" style="margin-left:257px;">Miejscowość</label><br>

                    <input type="text" style ="width:250px;float:left;margin-right:100px;" class="form-control" id="wojewodztwo">
                    <input type="text" style ="width:250px;" class="form-control" id="miejscowosc">
                  </div>
                  <div class="mb-3">
                    <label for="nazwaszkoly" class="form-label">Nazwa ukończenia szkoły średniej</label>
                    <label for="obywatelstwo" class="form-label" style="margin-left:138px;">Obywatelstwo</label><br>

                    <input type="text" style ="width:250px;float:left;margin-right:100px;" class="form-control" id="nazwaszkoly">
                    <input type="text" style ="width:250px;" class="form-control" id="obywatelstwo">
                  </div>
                  <div class="mb-3">
                    <label for="formFile" class="form-label">Zdjęcie kandydata</label>
                    <input class="form-control" type="file" id="formFile">
                  </div>
                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekt\resources\views/pages/formularz.blade.php ENDPATH**/ ?>