

<?php $__env->startSection('content'); ?>
            <div>
                <h1><b><?php echo e($title); ?></b></h1><hr><br>
                <ul>
                    <h2>Rekrutacja odbywa się w godzinach 8:00 - 15:30.<h2><br>
                <li><h3>Biuro do spraw rekrutacji UR - tel. +48 22 22 22 222</h3></li>
                <li><h3>Biuro do spraw studenckich UR - tel. +48 11 11 11 111</h3></li>
                <li><h3>Rekrutacja stacjonarnie ul. Przykładowa 9, bud A0, pokój nr 1</h3></li>
                </ul>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekt\resources\views/pages/kontakt.blade.php ENDPATH**/ ?>