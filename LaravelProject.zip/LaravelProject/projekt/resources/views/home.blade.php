@extends('layouts.app')

@section('content')
            
                <h1><b>Studia I stopnia</b></h1><hr>
                @if ($message = Session::get('status'))
                  <div class="alert alert-success alert-block text-green-600">
                        <strong>{{ $message }}</strong> 
                  </div>          
                @endif
            <div>
                <form action="{{ url('/zapiszsie1') }}">
                    <input type="submit" style="height:60px; background-color:rgb(126, 180, 235); color:Black; width:200px; font-size:27px;" value="Zapisz się!" />
                </form>
                <br>
                <form action="{{ url('/info1') }}">
                    <input type="submit" style="height:60px; background-color:rgb(126, 180, 235); color:Black; width:200px; font-size:27px;" value="Informacje" />
                </form>
                <br>

            </div>

@endsection
