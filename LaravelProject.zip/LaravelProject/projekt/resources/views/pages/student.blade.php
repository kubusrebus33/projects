@extends('layouts.app')

@section('content')
            <div>
                <h1><b>{{ $title }}</b></h1><hr>
            </div>
@endsection
