@extends('layouts.app')

@section('content')
            <h1> Moje dane </h1><hr><br>
                    
                    <table class="table table-hover">
                        <thead>
                            <h5>Dane użytkownika:</h5>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">imię</th>
                            <th scope="col">nazwisko</th>
                            <th scope="col">email</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>    
                        <th scope="row">{{ $data->id }}</th>
                        <td>{{ $data->name }}</td>
                        <td>{{ $data->surname }}</td>
                        <td>{{ $data->email }}</td>
                    </tbody>
                    </table><br>
                    <hr>
                    <table class="table table-hover">
                        <thead>
                            <h5>Moje wyniki z matur:</h5>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">matematyka</th>
                            <th scope="col">matematykar</th>
                            <th scope="col">jpolski</th>
                            <th scope="col">jangielski</th>
                            <th scope="col">jangielskir</th>
                            <th scope="col">informatyka</th>
                            <th scope="col">fizyka</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($data1 as $data)
                    
                    <tr>   
                        <th scope="row">{{ $data->id }}</th>
                        <td>{{ $data->matematyka }}</td>
                        <td>{{ $data->matematykar }}</td>
                        <td>{{ $data->jpolski }}</td>
                        <td>{{ $data->jangielski }}</td>
                        <td>{{ $data->jangielskir }}</td>
                        <td>{{ $data->informatyka }}</td>
                        <td>{{ $data->fizyka }}</td>
                    @endforeach     
                    </tbody>
                    </table>
                    <br>
                    <hr>
                </div>
                
                    <table class="table table-hover">
                        <thead>
                            <h5>Moje dane osobowe</h5>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">pesel</th>
                            <th scope="col">data urodzenia</th>
                            <th scope="col">imię matki</th>
                            <th scope="col">imię ojca</th>
                            <th scope="col">numer telefonu</th>
                            <th scope="col">kod pocztowy</th>
                            <th scope="col">ulica</th>
                            <th scope="col">numer domu</th>
                            <th scope="col">województwo</th>
                            <th scope="col">miejscowość</th>
                            <th scope="col">nazwa szkoły</th>
                            <th scope="col">obywatelstwo</th>
                            <th scope="col">kierunek</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        @foreach($data2 as $data)
                        
                    <tr>   
                        <th scope="row">{{ $data->id }}</th>
                        <td>{{ $data->pesel }}</td>
                        <td>{{ $data->data_urodzenia}}</td>
                        <td>{{ $data->imię_matki }}</td>
                        <td>{{ $data->imię_ojca }}</td>
                        <td>{{ $data->numer_telefonu }}</td>
                        <td>{{ $data->kod_pocztowy }}</td>
                        <td>{{ $data->ulica }}</td>
                        <td>{{ $data->numer_domu }}</td>
                        <td>{{ $data->województwo }}</td>
                        <td>{{ $data->miejscowość }}</td>
                        <td>{{ $data->nazwa_szkoły }}</td>
                        <td>{{ $data->obywatelstwo }}</td>
                        <td>{{ $data->kierunek }}</td>
                    @endforeach
                        
                        
                    </tbody>
                    </table>
                
@endsection
