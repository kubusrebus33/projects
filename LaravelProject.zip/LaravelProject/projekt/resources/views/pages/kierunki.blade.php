@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-6"> 
        <h1><b>Kierunki</b></h1>
        </div>
        <div class="col-6"> 
        <a href="/kierunki/create">
            <button type="button" style="float:right;" class="btn btn-success"> Dodaj </button>
        </a>
    </div>
    <hr>
    </div>  
            <div class="row">
                
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">nazwa</th>
                        <th scope="col">poziom</th>
                        <th scope="col">dlugosc trwania</th>
                        <th scope="col">oplata</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($fields as $field)
                    <tr>   
                        <th scope="row">{{ $field->id }}</th>
                        <td>{{ $field->name }}</td>
                        <td>{{ $field->level }}</td>
                        <td>{{ $field->length }}</td>
                        <td>{{ $field->recruitment_fee }}</td>
                        
                        <td>  
                            <a href="/kierunki/{{ $field->id }}">
                                <button class="btn btn-primary btn-sm" data-id="{{ $field -> id }}">
                                    Show
                                </button>   
                                 </a>  
                            <a href="/kierunki/edit/{{$field->id}}">
                                <button class="btn btn-warning btn-sm" data-id="{{ $field -> id }}">
                                    Edit
                                </button>
                            </a>
                            <a href="/delete/{{ $field->id }}">
                            <button class="btn btn-danger btn-sm" data-id="{{ $field -> id }}">
                                Del
                            </button>   
                             </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
                </table>
            </div>
        </div>
        </div>
</div>
@endsection
{{-- @section('javascript')
    const deleteUrl= "{{ url ('kierunki') }}/";
@endsection 
@section('js-files')
    <script src="{{ asset('js/delete.js') }}"></script>
@endsection --}}
