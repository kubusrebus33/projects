@extends('layouts.app')

@section('content')
                
            <form action="/formularz1" method="POST" >   
            @csrf      
              <h1>Dane osobowe</h1><hr><br>     
                <div class="mb-3">
                    <label for="pesel" class="form-label">PESEL</label>
                    <input type="text" placeholder="e.g. 99999999999" style ="width:250px;margin-right:100px;" class="form-control @error('pesel') is-invalid @enderror" value="{{ old('pesel') }}"  name="pesel">
                      @error('pesel')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                      @enderror
                      <br>

                    <label for="dataurodzenia" class="form-label" >Data urodzenia</label>
                    <input type="date" style ="width:250px;" placeholder="dd/mm/yyyy" class="form-control @error('data_urodzenia') is-invalid @enderror" value="{{ old('data_urodzenia') }}"  name="data_urodzenia"> 
                      @error('data_urodzenia')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                      @enderror
                  </div>
                  <div class="mb-3">
                    <label for="imiematki" class="form-label">Imię matki</label>
                    <input type="text"  style ="width:250px;margin-right:100px;" class="form-control @error('imię_matki') is-invalid @enderror" value="{{ old('imię_matki') }}"  name="imię_matki">
                      @error('imię_matki')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                      @enderror 

                    <label for="imieojca" class="form-label">Imię ojca</label><br>
                    <input type="text" style ="width:250px;"  class="form-control @error('imię_ojca') is-invalid @enderror" value="{{ old('imię_ojca') }}"  name="imię_ojca"> 
                      @error('imię_ojca')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                      @enderror

                  </div>
                  <div class="mb-3">
                    <label for="nrtel" class="form-label">Numer telefonu</label>
                    <input type="text" placeholder="e.g. 602555666" style ="width:250px;margin-right:100px;" class="form-control @error('numer_telefonu') is-invalid @enderror" value="{{ old('numer_telefonu') }}"  name="numer_telefonu">
                      @error('numer_telefonu')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                      @enderror

                    <label for="kodpocztowy" class="form-label">Kod pocztowy</label><br>
                    <input type="text" style ="width:250px;" class="form-control @error('kod_pocztowy') is-invalid @enderror" placeholder="e.g. 22-222" value="{{ old('kod_pocztowy') }}"  name="kod_pocztowy">
                      @error('kod_pocztowy')
                                      <span class="invalid-feedback" role="alert">
                                          <strong>{{ $message }}</strong>
                                      </span>
                      @enderror 
                  </div>
                  <div class="mb-3">
                    <label for="ulica" class="form-label">Ulica</label>
                    <input type="text" style ="width:250px;margin-right:100px;" class="form-control @error('ulica') is-invalid @enderror" value="{{ old('ulica') }}"  name="ulica">
                      @error('ulica')
                      <span class="invalid-feedback" role="alert">
                          <strong>{{ $message }}</strong>
                      </span>
                      @enderror

                    <label for="nrdomu" class="form-label">Numer domu</label><br>
                    <input type="number" style ="width:250px;" class="form-control @error('numer_domu') is-invalid @enderror"  value="{{ old('numer_domu') }}"  name="numer_domu">
                    @error('numer_domu')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                    @enderror
                  </div>
                  <div class="mb-3">
                    <label for="wojewodztwo" class="form-label">Województwo</label>
                    

                    <select name="województwo" class="form-control @error('województwo') is-invalid @enderror" value="{{ old('województwo') }}" >
                      <option value="dolnoslaskie">dolnośląskie</option>
                      <option value="kujawsko-pomorskie">kujawsko-pomorskie</option>
                      <option value="lubelskie">lubelskie</option>
                      <option value="lubuskie">lubuskie</option>
                      <option value="łódzkie">łódzkie</option>
                      <option value="małopolskie">małopolskie</option>
                      <option value="mazowieckie">mazowieckie</option>
                      <option value="opolskie">opolskie</option>
                      <option value="podkarpackie">podkarpackie</option>
                      <option value="podlaskie">podlaskie</option>
                      <option value="pomorskie">pomorskie</option>
                      <option value="śląskie">śląskie</option>
                      <option value="świętokrzyskie">świętokrzyskie</option>
                      <option value="warmińsko-mazurskie">warmińsko-mazurskie</option>
                      <option value="wielkopolskie">wielkopolskie</option>
                      <option value="zachodniopomorskie">zachodniopomorskie</option>
                    </select> 
                    @error('województwo')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                    <br>
                    <label for="miejscowosc" class="form-label">Miejscowość</label><br>
                    <input type="text" style ="width:250px;" class="form-control @error('miejscowość') is-invalid @enderror" value="{{ old('miejscowość') }}"  name="miejscowość">
                    
                    @error('miejscowość')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                    @enderror
                  </div>
                  <div class="mb-3">
                    <label for="nazwaszkoly" class="form-label">Nazwa ukończenia szkoły średniej</label>
                    

                    <input type="text" style ="width:250px;margin-right:100px;" class="form-control @error('nazwa_szkoły') is-invalid @enderror" value="{{ old('nazwa_szkoły') }}"  name="nazwa_szkoły">
                    @error('nazwa_szkoły')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                    @enderror
                    <label for="obywatelstwo" class="form-label">Obywatelstwo</label><br>
                    
                    <input type="text" style ="width:250px;" class="form-control @error('obywatelstwo') is-invalid @enderror" value="{{ old('obywatelstwo') }}"  name="obywatelstwo">
                    
                    @error('obywatelstwo')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                    @enderror
                  </div>
                  
                  <div class="mb-3">    
                  <label for="kierunek" class="form-label">Kierunek studiów</label>

                  <select name="kierunek" style ="width:250px;margin-right:100px;" class="form-control">
                    
                    @foreach ($fields as $field) 
                    <div class="well">
                        <option value="{{ $field->name }}">{{ $field->name }}</option>
                    </div>
                  @endforeach
                
                  </select>
                </div>
                  <br>
                  <button type ="submit" class="btn btn-danger btn-sm" data-id="{{ $id }}">
                      Dodaj
                  </button>   
               
              </form>

@endsection
