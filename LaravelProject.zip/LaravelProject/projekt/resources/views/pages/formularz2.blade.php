@extends('layouts.app')

@section('content')
            <form action="/formularz2" method="POST">   
                @csrf     
                <h1> Wyniki z matur</h1><hr><br>
                <div class="mb-3" style="font-size:25px;">
                    <label for="matematyka" class="form-label" style="margin-right:100px;"><b>Matematyka</b></label>
                    <input type="number" step="2" style ="width:150px;float:right;margin-left:50px;" class="form-control @error('matematyka') is-invalid @enderror" name="matematyka"><br>
                    @error('matematyka')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                    @enderror
                    <label for="jpolski" class="form-label" style="margin-right:100px;"><b>Język polski</b></label>
                    <input type="number" step="2" style ="width:150px;float:right;margin-left:50px;" class="form-control @error('jpolski') is-invalid @enderror" name="jpolski"><br>
                    @error('jpolski')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror                  
                    <label for="jangielski" class="form-label" style="margin-right:100px;"><b>Język angielski podstawowy</b></label>
                    <input type="number" step="2" style ="width:150px;float:right;margin-left:50px;" class="form-control @error('jangielski') is-invalid @enderror" name="jangielski"><br>
                    @error('jangielski')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror       
                    <label for="matematykar" class="form-label" style="margin-right:100px;"><b>Matematyka rozszerzona</b></label>
                    <input type="number" step="2" style ="width:150px;float:right;margin-left:50px;" class="form-control @error('matematykar') is-invalid @enderror" name="matematykar"><br>
                    @error('matematykar')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror   
                    <label for="jangielskir" class="form-label" style="margin-right:100px;"><b>Język angielski rozszerzony</b></label>
                    <input type="number" step="2" style ="width:150px;float:right;margin-left:50px;" class="form-control @error('jangielskir') is-invalid @enderror" name="jangielskir"><br>
                    @error('jangielskir')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror   
                    <label for="Informatyka" class="form-label" style="margin-right:100px;"><b>Informatyka</b></label>
                    <input type="number" step="2" style ="width:150px;float:right;margin-left:50px;" class="form-control @error('informatyka') is-invalid @enderror" name="informatyka"><br>
                    @error('informatyka')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror   
                    <label for="Fizyka" class="form-label" style="margin-right:100px;"><b>Fizyka</b></label>
                    <input type="number" step="2" style ="width:150px;float:right;margin-left:50px;" class="form-control @error('fizyka') is-invalid @enderror" name="fizyka"><br>
                    @error('fizyka')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror   
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
@endsection
