@extends('layouts.app')

@section('content')
            <div>
                <h1><b>{{ $title  }}</b></h1><hr>
                    Kto może podjąć studia?

                    Studia mogą podjąć osoby posiadające:

                    <ol>polską nową maturę (2002–2022),
                    <li>polskie świadectwo dojrzałości (tzw. stara matura, wydawana do 2005 roku),</li>
                    <li>maturę International Baccalaureate, </li>
                    <li>maturę European Baccalaureate, </li>
                    <li>inny dokument, który uprawnia do podjęcia studiów pierwszego stopnia lub jednolitych magisterskich w kraju, w którym został wydany. </li>
                    </ol>
                    Podczas dokonywania zgłoszenia rekrutacyjnego kandydat nie musi posiadać wyżej wymienionych dokumentów oraz wyników egzaminów. Termin na ich wprowadzenie oraz na wczytanie dokumentów (o ile są wymagane) do systemu określa harmonogram. 
            </div>
@endsection
