@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Podgląd kierunku</div>

                <div class="card-body">

                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">Nazwa</label>

                            <div class="col-md-6">
                                <input name="name" type="text" value="{{ $fields ->name }}" disabled>

                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="level" class="col-md-4 col-form-label text-md-end">{{ __('Poziom') }}</label>

                            <div class="col-md-6">
                                <input name="level" type="text" name="level" value="{{ $fields ->level }}" disabled>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="length" class="col-md-4 col-form-label text-md-end">{{ __('długość') }}</label>

                            <div class="col-md-6">
                                <input name="length" type="text" value="{{ $fields ->length }}" disabled>
                                
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="recruitment_fee" class="col-md-4 col-form-label text-md-end">{{ __('opłata') }}</label>

                            <div class="col-md-6">
                                <input name="recruitment_fee" type="text" value="{{ $fields ->recruitment_fee }}" disabled>

                            </div>
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
