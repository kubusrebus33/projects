@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dodawanie kierunku</div>

                <div class="card-body">
                    <form method="POST" action="/kierunki/create">
                        @csrf

                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">Nazwa</label>

                            <div class="col-md-6">
                                <input name="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" required="required" autofocus>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="level" class="col-md-4 col-form-label text-md-end">{{ __('Poziom') }}</label>

                            <div class="col-md-6">
                                <input name="level" type="text" class="form-control @error('level') is-invalid @enderror" name="level"  required="required" autofocus>

                                @error('level')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="length" class="col-md-4 col-form-label text-md-end">{{ __('długość') }}</label>

                            <div class="col-md-6">
                                <input name="length" type="text" class="form-control @error('length') is-invalid @enderror" required="required" name="length">
                                @error('length')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="recruitment_fee" class="col-md-4 col-form-label text-md-end">{{ __('opłata') }}</label>

                            <div class="col-md-6">
                                <input name="recruitment_fee" type="text" class="form-control @error('recruitment_fee') is-invalid @enderror"  required="required" name="recruitment_fee" >

                                @error('recruitment_fee')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>


                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Dodaj') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
