@extends('layouts.app')

@section('content')
            <div>
                <h1><b>Zapisz się na studia I stopnia</b></h1><hr>

                @foreach ($fields as $field) 
                    <div class="well">
                        <a href="/formularz1"><h1>{{ $field->name }}</a></h1>
                            <h5>---Poziom: {{ $field->level }}</h5>
                            <h5>---Ilość semestrów: {{ $field->length }}</h5>
                            <h5>---Opłata rekrutacyjna: {{ $field->recruitment_fee }}</h5>
                    </div>
                @endforeach
                <br>   
            </div>
@endsection
