<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Application extends Model
{
    
    protected $fillable = [
        'pesel',
        'data_urodzenia',
        'imię_matki',
        'imię_ojca',
        'numer_telefonu',
        'kod_pocztowy',
        'ulica',
        'numer_domu',
        'województwo',
        'miejscowość',
        'nazwa_szkoły',
        'obywatelstwo',
        'kierunek',
        'user_id'
    ];
}
