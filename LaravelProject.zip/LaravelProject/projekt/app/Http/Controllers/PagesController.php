<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function student()
    {
        $title = "Student";
        return view('pages.student', compact('title'));
    }
    public function index()
    {
        return view('home');
    }
    public function kandydat()
    {
        $title = "Kandydat";
        return view('pages.kandydat', compact('title'));
    }
    public function kontakt()
    {
        $title = "Kontakt";
        return view('pages.kontakt', compact('title'));
    }
    public function zapiszsie1()
    {
        return view('pages.zapiszsie1');
    }
    public function zapiszsie2()
    {
        return view('pages.zapiszsie2');
    }
    public function info1()
    {
        $title = "Informacje o studiach I stopnia";
        return view('pages.info1', compact('title'));
    }
    public function info2()
    {
        $title = "Informacje o studiach II stopnia";
        return view('pages.info2', compact('title'));
    }
    public function sukces()
    {
        return view('pages.sukces');
    }
    
    
}
  


