<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\FieldOfStudy;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
 

class FieldOfStudyController extends Controller
{
    
    public function index()
    {
        $fields = DB::table('fieldofstudy')->get();
        return view('pages.zapiszsie1', ['fields' => $fields]);
    }
    public function index2()
    {
        $fields = DB::table('fieldofstudy')->get();
        return view('pages.kierunki', ['fields' => $fields]);
    }
    public function create()
    {
        return view('pages.create');
    }
    public function store(request $request)
    {
        FieldOfStudy::create([
            'name' => $request['name'],
            'level' => $request['level'],
            'length' => $request['length'],
            'recruitment_fee' => $request['recruitment_fee']
        ]);
        $fields = DB::table('fieldofstudy')->get();
        return view('pages.kierunki', ['fields' => $fields]);
    }
    public function edit(FieldOfStudy $fieldofstudy)
    {
        return view('pages.edit', ['field' => $fieldofstudy]);
    }
    public function update(Request $request, FieldOfStudy $fieldofstudy)
    {
        $fieldofstudy->fill($request->all());
        $fieldofstudy->save();

        return redirect('kierunki');
    }
    public function delete($id)
    {
        $data = FieldOfStudy::find($id) ;
        $data -> delete();
        
        return redirect('kierunki');
    }
    public function show(FieldOfStudy $fieldofstudy)
    {
        return view('pages.show', ['fields' => $fieldofstudy]);
    }
}

