<?php

namespace App\Http\Controllers;
use App\Models\Result;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use App\Models\Application;
use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

use Illuminate\Http\Request;

class FormController extends Controller
{
    public function form1()
    {
        $fields = DB::table('fieldofstudy')->get();
        $id = Auth::id();
        return view('pages.formularz1', ['fields' => $fields], ['id' => $id]);
    }
    public function form2()
    {
        $fields = DB::table('users')->get();
        return view('pages.formularz2', ['fields' => $fields]);
    }

    protected function createResult(Request $request)
    {

        $request ->validate([
            'matematyka' => 'required|integer|max:100|min:0',
            'matematykar' => 'required|integer|max:100|min:0',
            'jpolski' => 'required|integer|max:100|min:0',
            'jangielski' => 'required|integer|max:100|min:0',
            'jangielskir' => 'required|integer|max:100|min:0',
            'informatyka' => 'required|integer|max:100|min:0',
            'fizyka' => 'required|integer|max:100|min:0',
        ]);
        $id = Auth::id();
        Result::create([
            'user_id' => $id,
            'matematyka' => $request['matematyka'],
            'matematykar' => $request['matematykar'],
            'jpolski' => $request['jpolski'],
            'jangielski' => $request['jangielski'],
            'jangielskir' => $request['jangielskir'],
            'informatyka' => $request['informatyka'],
            'fizyka' => $request['fizyka'],
        ]);
        return redirect('home')->with('status', 'Udało się wypełnić formularz!');
    }

    protected function createApplication(Request $request)
    {
    $request ->validate([
        'pesel' => 'required|string|max:11|min:11',
        'data_urodzenia' => 'required|date_format:Y-m-d',       
        'imię_matki' => 'required|string|max:40|min:3',
        'imię_ojca' => 'required|string|max:40|min:3',
        'numer_telefonu' => 'required|string|max:9|min:9',
        'kod_pocztowy' => 'required|string|max:6|min:6',
        'ulica' => 'required|string|max:40|min:8',
        'numer_domu' => 'required|integer|min:1',
        'miejscowość' => 'required|string|max:40',
        'nazwa_szkoły' => 'required|string|max:40',
        'obywatelstwo' => 'required|string|max:40',
    ]);

        $id = Auth::id();
        Application::create([
            'pesel' => $request['pesel'],
            'data_urodzenia' => $request['data_urodzenia'],
            'imię_matki' => $request['imię_matki'],
            'imię_ojca' => $request['imię_ojca'],
            'numer_telefonu' => $request['numer_telefonu'],
            'kod_pocztowy' => $request['kod_pocztowy'],
            'ulica' => $request['ulica'],
            'numer_domu' => $request['numer_domu'],
            'województwo' => $request['województwo'],
            'miejscowość' => $request['miejscowość'],
            'nazwa_szkoły' => $request['nazwa_szkoły'],
            'obywatelstwo' => $request['obywatelstwo'],
            'kierunek' => $request['kierunek'],
            'user_id' => $id
        ]);
        
        
        return redirect('home')->with('status', 'Udało się wypełnić formularz!');
    }
}
